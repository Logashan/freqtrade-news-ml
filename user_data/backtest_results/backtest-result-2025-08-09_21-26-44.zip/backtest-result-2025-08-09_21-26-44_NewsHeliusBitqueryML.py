from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import pandas as pd
import ta

class NewsHeliusBitqueryML(IStrategy):
    """
    Базовая рабочая версия:
    - Фильтр тренда: EMA50 > EMA200 (лонг), EMA50 < EMA200 (шорт)
    - Волатильность: ATR/close > порога
    - Временной фильтр: торги по UTC 6..22
    - Входы: пересечения RSI порогов + ADX + MACD
    - Выходы: RSI/EMA + ROI/SL из конфига
    """
    timeframe = "5m"
    can_short = False
    process_only_new_candles = True
    startup_candle_count = 240
    minimal_roi = {"0": 0.01, "30": 0.005, "90": 0.0}
    stoploss = -0.02
    use_exit_signal = True
    trailing_stop = True
    trailing_stop_positive = 0.004
    trailing_stop_positive_offset = 0.009
    trailing_only_offset_is_reached = True
    ignore_buying_expired_candle_after = 1

    # --- простые индикаторы на pandas ---
    @staticmethod
    def _ema(series: pd.Series, length: int) -> pd.Series:
        return series.ewm(span=length, adjust=False).mean()

    @staticmethod
    def _rsi(series: pd.Series, length: int = 14) -> pd.Series:
        delta = series.diff()
        up = delta.clip(lower=0)
        down = (-delta.clip(upper=0))
        ma_up = up.ewm(alpha=1/length, adjust=False, min_periods=length).mean()
        ma_down = down.ewm(alpha=1/length, adjust=False, min_periods=length).mean()
        rs = ma_up / (ma_down.replace(0, 1e-9))
        return 100 - (100 / (1 + rs))

    @staticmethod
    def _atr(df: DataFrame, length: int = 14) -> pd.Series:
        high, low, close = df['high'], df['low'], df['close']
        tr = pd.concat([
            (high - low),
            (high - close.shift()).abs(),
            (low - close.shift()).abs()
        ], axis=1).max(axis=1)
        return tr.ewm(alpha=1/length, adjust=False, min_periods=length).mean()

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        df['ema_fast'] = self._ema(df['close'], 50)
        df['ema_slow'] = self._ema(df['close'], 200)
        df['rsi'] = self._rsi(df['close'], 14)
        df['atr'] = self._atr(df, 14)
        df['vol_frac'] = (df['atr'] / df['close']).fillna(0)
        
        # Добавляем ADX и MACD через ta
        df["adx"] = ta.trend.adx(df["high"], df["low"], df["close"], window=14)
        macd = ta.trend.macd(df["close"], window_slow=26, window_fast=12)
        macd_sig = ta.trend.macd_signal(df["close"], window_slow=26, window_fast=12, window_sign=9)
        df["macd"], df["macd_sig"] = macd, macd_sig

        hours = df['date'].dt.hour if 'date' in df.columns else df.index.tz_convert('UTC').hour
        df['tradable_hour'] = ((hours >= 6) & (hours <= 22)).astype(int)

        df.ffill(inplace=True)
        df.bfill(inplace=True)
        return df

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()

        vol_min = 0.002     # ~0.2% средней 5m-волы (смягчено с 0.003)
        rsi_long_th = 45    # смягчено с 40
        rsi_short_th = 55   # смягчено с 60

        long_cond = (
            (df['ema_fast'] > df['ema_slow']) &
            (df['vol_frac'] > vol_min) &
            (df['macd'] > df['macd_sig']) &
            (df['adx'] >= 14) &  # смягчено с 18
            (df['rsi'].shift(1) < rsi_long_th) & (df['rsi'] >= rsi_long_th)
            # (df['tradable_hour'] == 1)  # временно закомментировано для 24/7 торговли
        )
        df['enter_long'] = long_cond.astype(int)
        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        exit_long = ( (df['rsi'] > 70) | (df['close'] < df['ema_fast']) )
        df['exit_long'] = exit_long.astype(int)
        return df

    @property
    def protections(self):
        return [
            {"method": "CooldownPeriod", "stop_duration_candles": 5},
            {"method": "StoplossGuard", "lookback_period_candles": 288,
             "stop_duration_candles": 30, "only_per_pair": False, "trade_limit": 2},
            {"method": "MaxDrawdown", "lookback_period_candles": 288,
             "stop_duration_candles": 60, "max_allowed_drawdown": 8,
             "only_per_pair": False}
        ]