import logging
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime, timedelta
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from freqtrade.strategy.parameters import CategoricalParameter
from freqtrade.persistence import Trade
from freqtrade.exchange import timeframe_to_minutes
import talib.abstract as ta
import warnings
warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)

class NewsHeliusBitqueryML(IStrategy):
    timeframe = "5m"
    can_short = False
    process_only_new_candles = True
    startup_candle_count = 240
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    position_adjustment_enable = False
    order_time_in_force = {
        "entry": "GTC",
        "exit": "GTC"
    }
    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "limit",
        "stoploss_on_exchange": False,
        "stoploss_on_exchange_interval": 60,
    }
    
    # Параметры для гипероптимизации ROI
    minimal_roi = {
        "0": 0.01,
        "30": 0.005,
        "90": 0.0
    }
    
    stoploss = -0.02
    
    trailing_stop = True
    trailing_stop_positive = 0.004
    trailing_stop_positive_offset = 0.009
    trailing_only_offset_is_reached = True
    
    ignore_buying_expired_candle_after = 1
    
    # Параметры для гипероптимизации
    buy_params = {
        "vol_min": 0.002,
        "rsi_long_th": 45,
        "adx_min": 14,
        "ema_fast": 12,
        "ema_slow": 26,
        "rsi_period": 14,
        "macd_fast": 12,
        "macd_slow": 26,
        "macd_signal": 9,
        "atr_period": 14
    }
    
    sell_params = {
        "rsi_exit_long": 70,
        "ema_exit_long": True
    }
    
    # Параметры для гипероптимизации ROI
    roi_params = {
        "roi_0": 0.01,
        "roi_30": 0.005,
        "roi_90": 0.0
    }
    
    # Параметры для гипероптимизации Stoploss
    stoploss_params = {
        "stoploss": -0.02
    }
    
    # Параметры для гипероптимизации Trailing Stop
    trailing_params = {
        "trailing_stop": True,
        "trailing_stop_positive": 0.004,
        "trailing_stop_positive_offset": 0.009,
        "trailing_only_offset_is_reached": True
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        
        # EMA
        df['ema_fast'] = ta.EMA(df, timeperiod=self.buy_params['ema_fast'])
        df['ema_slow'] = ta.EMA(df, timeperiod=self.buy_params['ema_slow'])
        
        # RSI
        df['rsi'] = ta.RSI(df, timeperiod=self.buy_params['rsi_period'])
        
        # MACD
        df['macd'], df['macd_sig'], df['macd_hist'] = ta.MACD(
            df, 
            fastperiod=self.buy_params['macd_fast'], 
            slowperiod=self.buy_params['macd_slow'], 
            signalperiod=self.buy_params['macd_signal']
        )
        
        # ADX
        df['adx'] = ta.ADX(df, timeperiod=14)
        
        # ATR
        df['atr'] = ta.ATR(df, timeperiod=self.buy_params['atr_period'])
        
        # Volume fraction
        df['vol_frac'] = df['volume'] / df['volume'].rolling(window=20).mean()
        
        # DEBUG: покажем статистику по индикаторам
        try:
            logger.info(f"[DBG] indicators stats: ema_fast_nan={df['ema_fast'].isna().sum()}, "
                       f"ema_slow_nan={df['ema_slow'].isna().sum()}, "
                       f"rsi_nan={df['rsi'].isna().sum()}, "
                       f"macd_nan={df['macd'].isna().sum()}, "
                       f"adx_nan={df['adx'].isna().sum()}, "
                       f"vol_frac_nan={df['vol_frac'].isna().sum()}, "
                       f"total_rows={len(df)}")
        except Exception as e:
            logger.warning(f"[DBG] indicators stats error: {e}")
        
        return df

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        
        vol_min = self.buy_params['vol_min']
        rsi_long_th = self.buy_params['rsi_long_th']
        adx_min = self.buy_params['adx_min']
        
        long_cond = (
            (df['ema_fast'] > df['ema_slow']) &
            (df['vol_frac'] > vol_min) &
            (df['macd'] > df['macd_sig']) &
            (df['adx'] >= adx_min) &
            (df['rsi'].shift(1) < rsi_long_th) & (df['rsi'] >= rsi_long_th)
        )
        
        df['enter_long'] = long_cond.astype(int)
        
        # DEBUG: покажем, сколько сигналов сформировалось на этом батче
        try:
            long_cnt = int(df.get("enter_long", 0).fillna(0).sum())
            short_cnt = int(df.get("enter_short", 0).fillna(0).sum())
            logger.info(f"[DBG] signals: long={long_cnt}, short={short_cnt}, rows={len(df)}")
        except Exception as e:
            logger.warning(f"[DBG] signals error: {e}")
        
        return df

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        df = dataframe.copy()
        
        rsi_exit_long = self.sell_params['rsi_exit_long']
        ema_exit_long = self.sell_params['ema_exit_long']
        
        exit_long = (
            (df['rsi'] > rsi_exit_long) | 
            (ema_exit_long and df['close'] < df['ema_fast'])
        )
        
        df['exit_long'] = exit_long.astype(int)
        
        # DEBUG: покажем, сколько сигналов выхода сформировалось
        try:
            exit_cnt = int(df.get("exit_long", 0).fillna(0).sum())
            logger.info(f"[DBG] exit signals: exit_long={exit_cnt}, rows={len(df)}")
        except Exception as e:
            logger.warning(f"[DBG] exit signals error: {e}")
        
        return df
    
    # Методы для гипероптимизации ROI
    def custom_roi(self, dataframe: DataFrame, trade: Trade, current_time: datetime, **kwargs) -> float:
        # Динамический ROI на основе времени удержания позиции
        open_minutes = (current_time - trade.open_date_utc).total_seconds() / 60
        
        if open_minutes <= 30:
            return self.roi_params['roi_0']
        elif open_minutes <= 90:
            return self.roi_params['roi_30']
        else:
            return self.roi_params['roi_90']
    
    # Методы для гипероптимизации Stoploss
    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime, current_rate: float, current_profit: float, **kwargs) -> float:
        return self.stoploss_params['stoploss']
    
    # Методы для гипероптимизации Trailing Stop
    def custom_trailing_stop(self, pair: str, trade: Trade, current_time: datetime, current_rate: float, current_profit: float, **kwargs) -> float:
        if not self.trailing_params['trailing_stop']:
            return 0
        
        if current_profit > self.trailing_params['trailing_stop_positive_offset']:
            return self.trailing_params['trailing_stop_positive']
        
        return 0

    @property
    def protections(self):
        return [
            {"method": "CooldownPeriod", "stop_duration_candles": 5},
            {"method": "StoplossGuard", "lookback_period_candles": 288,
             "stop_duration_candles": 30, "only_per_pair": False, "trade_limit": 2},
            {"method": "MaxDrawdown", "lookback_period_candles": 288,
             "stop_duration_candles": 60, "max_allowed_drawdown": 8,
             "only_per_pair": False}
        ]